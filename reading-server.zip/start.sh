#!/bin/bash
echo "`date +%Y-%m-%d,%H:%M:%S` pm2启动"
npm run start-prod